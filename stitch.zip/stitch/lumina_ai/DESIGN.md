---
name: Lumina AI
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bacac5'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#859490'
  outline-variant: '#3c4a46'
  surface-tint: '#3cddc7'
  primary: '#57f1db'
  on-primary: '#003731'
  primary-container: '#2dd4bf'
  on-primary-container: '#00574d'
  inverse-primary: '#006b5f'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#cbdaff'
  on-tertiary: '#002e6a'
  tertiary-container: '#a0beff'
  on-tertiary-container: '#0049a1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#62fae3'
  primary-fixed-dim: '#3cddc7'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005047'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.02em
  code-sm:
    fontFamily: jetbrainsMono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1200px
  sidebar-width: 280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

This design system is built for a premium, high-performance AI RAG environment. The brand personality is sophisticated, highly technical, and whisper-quiet, allowing user data and AI insights to take center stage. 

The aesthetic is **Modern Glassmorphism** layered over a **Deep Minimalist** foundation. It leverages high-transparency surfaces, expansive whitespace (negative space), and precision-engineered typography to evoke a sense of infinite intelligence. Emotional responses should range from focused calm to the excitement of cutting-edge discovery. Key visual drivers include ultra-fine "micro-borders," vibrant neon accents used sparingly for state-signaling, and deep atmospheric depth.

## Colors

The palette is optimized for OLED displays and low-light environments. 

- **Foundation:** The core interface uses `#050505` for the base background. Surfaces that require elevation use `#0A0A0B`.
- **Accents:** Neon hues are used for "moments of intelligence." **Electric Blue** (#3B82F6) denotes processing states, **Vivid Purple** (#A855F7) identifies AI-generated insights, and **Cyan** (#2DD4BF) serves as the primary action color.
- **Translucency:** Neutral colors are rarely solid; they are implemented as semi-transparent layers to allow background blurs to create depth.

## Typography

The typography system prioritizes clarity and technical precision. **Geist** is used for structural elements, headings, and UI labels to provide a distinctively "engineered" feel. **Inter** is reserved for chat bubbles and long-form AI responses to ensure maximum readability during extended sessions.

For code blocks and technical metadata, use **JetBrains Mono**. All headings should utilize tighter letter spacing to maintain a premium, high-density editorial look.

## Layout & Spacing

The layout follows a **Fluid-Fixed Hybrid** model. The sidebar remains fixed at 280px, while the main chat stream is a centered, max-width fluid container (1200px) to prevent line lengths from becoming unreadable.

A strict 4px spacing grid is used for all internal component padding. Generous whitespace is mandated between chat turns (minimum 32px) to signify the separation of context. On mobile, margins reduce to 16px and the sidebar transitions to a full-screen glass overlay.

## Elevation & Depth

Depth is achieved through **Backdrop Filtering** rather than traditional drop shadows. 

- **Level 1 (Base):** Deep black background (#050505).
- **Level 2 (Panels):** Translucent overlays with a 20px-40px blur and a 1px solid border at 8% white opacity.
- **Level 3 (Popovers/Modals):** Increased saturation in the background blur, with a subtle "outer glow" using the primary accent color at 5% opacity.

Avoid heavy shadows; use "inner glows" (box-shadow: inset) on active input fields to simulate a light source coming from within the AI interface.

## Shapes

The design system uses a **Rounded** shape language to soften the high-tech aesthetic. Standard buttons and input fields use an 8px (0.5rem) radius. Message bubbles for the AI use a 16px (1rem) radius, except for the corner adjacent to the avatar. 

Interactive cards and upload zones utilize the 24px (1.5rem) `rounded-xl` token to distinguish them from standard interface elements.

## Components

- **Message Bubbles:** User messages are simple, outlined containers. AI messages are glassmorphic with a subtle gradient mesh background in the corner (Purple to Blue at 10% opacity).
- **Input Field:** The main prompt bar is a floating pill-shaped glass container. On focus, it gains a 1px glowing border of the primary color and a subtle bottom-glow.
- **Action Buttons:** Use a "Glass-Primary" style—translucent background with high-saturation text and a sharp 1px border.
- **File Cards:** For RAG uploads, use a compact horizontal card with a monospaced font for the file extension and a micro-progress bar for upload states.
- **Scrollbars:** Custom minimal scrollbars; 4px wide, rounded, in a muted grey that only appears on hover.
- **Status Indicators:** Use "breathing" animations (soft opacity pulses) for AI "thinking" states, utilizing the Cyan accent color.